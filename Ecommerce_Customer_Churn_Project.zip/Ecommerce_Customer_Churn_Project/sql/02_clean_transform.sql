-- E-Commerce Customer Churn Analysis
-- Run after 01_create_and_load_database.sql in MySQL Workbench.
USE ecomm;

-- 1. Remove warehouse-to-home outliers (> 100 km), as specified in the assignment.
SET SQL_SAFE_UPDATES = 0;
DELETE FROM customer_churn WHERE WarehouseToHome > 100;
SET SQL_SAFE_UPDATES = 1;

-- 2. Impute mean values for specified columns.
UPDATE customer_churn
SET WarehouseToHome = (SELECT mean_value FROM
    (SELECT ROUND(AVG(WarehouseToHome)) AS mean_value FROM customer_churn) AS m)
WHERE WarehouseToHome IS NULL;

UPDATE customer_churn
SET HourSpendOnApp = (SELECT mean_value FROM
    (SELECT ROUND(AVG(HourSpendOnApp)) AS mean_value FROM customer_churn) AS m)
WHERE HourSpendOnApp IS NULL;

UPDATE customer_churn
SET OrderAmountHikeFromlastYear = (SELECT mean_value FROM
    (SELECT ROUND(AVG(OrderAmountHikeFromlastYear)) AS mean_value FROM customer_churn) AS m)
WHERE OrderAmountHikeFromlastYear IS NULL;

UPDATE customer_churn
SET DaySinceLastOrder = (SELECT mean_value FROM
    (SELECT ROUND(AVG(DaySinceLastOrder)) AS mean_value FROM customer_churn) AS m)
WHERE DaySinceLastOrder IS NULL;

-- 3. Impute mode values (most frequent value; ties resolve to the smallest value).
UPDATE customer_churn
SET Tenure = (SELECT mode_value FROM
    (SELECT Tenure AS mode_value FROM customer_churn WHERE Tenure IS NOT NULL
     GROUP BY Tenure ORDER BY COUNT(*) DESC, Tenure ASC LIMIT 1) AS m)
WHERE Tenure IS NULL;

UPDATE customer_churn
SET CouponUsed = (SELECT mode_value FROM
    (SELECT CouponUsed AS mode_value FROM customer_churn WHERE CouponUsed IS NOT NULL
     GROUP BY CouponUsed ORDER BY COUNT(*) DESC, CouponUsed ASC LIMIT 1) AS m)
WHERE CouponUsed IS NULL;

UPDATE customer_churn
SET OrderCount = (SELECT mode_value FROM
    (SELECT OrderCount AS mode_value FROM customer_churn WHERE OrderCount IS NOT NULL
     GROUP BY OrderCount ORDER BY COUNT(*) DESC, OrderCount ASC LIMIT 1) AS m)
WHERE OrderCount IS NULL;

-- 4. Standardize inconsistent text values.
UPDATE customer_churn SET PreferredLoginDevice = 'Mobile Phone' WHERE PreferredLoginDevice = 'Phone';
UPDATE customer_churn SET PreferedOrderCat = 'Mobile Phone' WHERE PreferedOrderCat = 'Mobile';
UPDATE customer_churn SET PreferredPaymentMode = 'Cash on Delivery' WHERE PreferredPaymentMode = 'COD';
UPDATE customer_churn SET PreferredPaymentMode = 'Credit Card' WHERE PreferredPaymentMode = 'CC';

-- 5. Rename columns requested in the assignment.
ALTER TABLE customer_churn RENAME COLUMN PreferedOrderCat TO PreferredOrderCat;
ALTER TABLE customer_churn RENAME COLUMN HourSpendOnApp TO HoursSpentOnApp;

-- 6. Add readable categorical columns before dropping binary source columns.
ALTER TABLE customer_churn ADD COLUMN ComplaintReceived VARCHAR(3);
ALTER TABLE customer_churn ADD COLUMN ChurnStatus VARCHAR(10);

UPDATE customer_churn
SET ComplaintReceived = CASE WHEN Complain = 1 THEN 'Yes' ELSE 'No' END,
    ChurnStatus = CASE WHEN Churn = 1 THEN 'Churned' ELSE 'Active' END;

-- 7. Drop original binary columns, as required.
ALTER TABLE customer_churn DROP COLUMN Churn, DROP COLUMN Complain;

-- 8. Validation checks.
SELECT COUNT(*) AS remaining_customers FROM customer_churn;
SELECT ChurnStatus, COUNT(*) AS customer_count
FROM customer_churn GROUP BY ChurnStatus;
SELECT * FROM customer_churn LIMIT 10;
