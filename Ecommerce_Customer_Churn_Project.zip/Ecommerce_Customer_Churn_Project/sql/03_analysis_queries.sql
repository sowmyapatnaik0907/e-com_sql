-- E-Commerce Customer Churn Analysis: analysis queries
USE ecomm;

-- 1. Retrieve the count of churned and active customers
SELECT ChurnStatus, COUNT(*) AS CustomerCount FROM customer_churn GROUP BY ChurnStatus ORDER BY ChurnStatus;

-- 2. Average tenure and total cashback for churned customers
SELECT ROUND(AVG(Tenure), 2) AS AverageTenure, SUM(CashbackAmount) AS TotalCashback FROM customer_churn WHERE ChurnStatus = 'Churned';

-- 3. Percentage of churned customers who complained
SELECT ROUND(100.0 * SUM(CASE WHEN ComplaintReceived='Yes' THEN 1 ELSE 0 END) / COUNT(*), 2) AS ComplaintPercentage FROM customer_churn WHERE ChurnStatus='Churned';

-- 4. City tier with most churned Laptop & Accessory customers
SELECT CityTier, COUNT(*) AS ChurnedCustomerCount FROM customer_churn WHERE ChurnStatus='Churned' AND PreferredOrderCat='Laptop & Accessory' GROUP BY CityTier ORDER BY ChurnedCustomerCount DESC, CityTier LIMIT 1;

-- 5. Most preferred payment mode among active customers
SELECT PreferredPaymentMode, COUNT(*) AS CustomerCount FROM customer_churn WHERE ChurnStatus='Active' GROUP BY PreferredPaymentMode ORDER BY CustomerCount DESC, PreferredPaymentMode LIMIT 1;

-- 6. Total order amount hike for single customers preferring mobile phones
SELECT SUM(OrderAmountHikeFromlastYear) AS TotalOrderAmountHike FROM customer_churn WHERE MaritalStatus='Single' AND PreferredOrderCat='Mobile Phone';

-- 7. Average registered devices among customers using UPI
SELECT ROUND(AVG(NumberOfDeviceRegistered), 2) AS AverageDevicesRegistered FROM customer_churn WHERE PreferredPaymentMode='UPI';

-- 8. City tier with highest number of customers
SELECT CityTier, COUNT(*) AS CustomerCount FROM customer_churn GROUP BY CityTier ORDER BY CustomerCount DESC, CityTier LIMIT 1;

-- 9. Gender that used the highest total number of coupons
SELECT Gender, SUM(CouponUsed) AS TotalCouponsUsed FROM customer_churn GROUP BY Gender ORDER BY TotalCouponsUsed DESC, Gender LIMIT 1;

-- 10. Customer count and maximum app hours per preferred order category
SELECT PreferredOrderCat, COUNT(*) AS CustomerCount, MAX(HoursSpentOnApp) AS MaxHoursSpentOnApp FROM customer_churn GROUP BY PreferredOrderCat ORDER BY PreferredOrderCat;

-- 11. Total order count for credit-card customers with maximum satisfaction score
SELECT SUM(OrderCount) AS TotalOrderCount FROM customer_churn WHERE PreferredPaymentMode='Credit Card' AND SatisfactionScore=(SELECT MAX(SatisfactionScore) FROM customer_churn);

-- 12. Average satisfaction score of customers who complained
SELECT ROUND(AVG(SatisfactionScore), 2) AS AverageSatisfactionScore FROM customer_churn WHERE ComplaintReceived='Yes';

-- 13. Preferred order categories for customers using more than 5 coupons
SELECT DISTINCT PreferredOrderCat FROM customer_churn WHERE CouponUsed > 5 ORDER BY PreferredOrderCat;

-- 14. Top three categories by average cashback
SELECT PreferredOrderCat, ROUND(AVG(CashbackAmount), 2) AS AverageCashback FROM customer_churn GROUP BY PreferredOrderCat ORDER BY AverageCashback DESC LIMIT 3;

-- 15. Payment modes for customers with tenure 10 months and more than 500 orders (as written in assignment)
SELECT DISTINCT PreferredPaymentMode FROM customer_churn WHERE Tenure=10 AND OrderCount > 500 ORDER BY PreferredPaymentMode;

-- 16. Churn status breakdown by warehouse-to-home distance category
SELECT CASE WHEN WarehouseToHome <= 5 THEN 'Very Close Distance' WHEN WarehouseToHome <= 10 THEN 'Close Distance' WHEN WarehouseToHome <= 15 THEN 'Moderate Distance' ELSE 'Far Distance' END AS DistanceCategory, ChurnStatus, COUNT(*) AS CustomerCount FROM customer_churn GROUP BY DistanceCategory, ChurnStatus ORDER BY CASE DistanceCategory WHEN 'Very Close Distance' THEN 1 WHEN 'Close Distance' THEN 2 WHEN 'Moderate Distance' THEN 3 ELSE 4 END, ChurnStatus;

-- 17. Order details for married City Tier-1 customers whose order count exceeds the overall average
SELECT CustomerID, Tenure, PreferredLoginDevice, CityTier, PreferredPaymentMode, PreferredOrderCat, OrderCount, ChurnStatus FROM customer_churn WHERE MaritalStatus='Married' AND CityTier=1 AND OrderCount > (SELECT AVG(OrderCount) FROM customer_churn) ORDER BY OrderCount DESC, CustomerID;

-- 18. Create and populate the returns table. DROP makes this section repeatable.
DROP TABLE IF EXISTS customer_returns;
CREATE TABLE customer_returns (
    ReturnID INT PRIMARY KEY,
    CustomerID INT,
    ReturnDate DATE,
    RefundAmount INT
);
INSERT INTO customer_returns (ReturnID, CustomerID, ReturnDate, RefundAmount) VALUES
(1001,50022,'2023-01-01',2130),
(1002,50316,'2023-01-23',2000),
(1003,51099,'2023-02-14',2290),
(1004,52321,'2023-03-08',2510),
(1005,52928,'2023-03-20',3000),
(1006,53749,'2023-04-17',1740),
(1007,54206,'2023-04-21',3250),
(1008,54838,'2023-04-30',1990);

-- 19. Return details joined to customer details for churned customers who complained.
SELECT r.ReturnID, r.CustomerID, r.ReturnDate, r.RefundAmount, c.Tenure, c.PreferredLoginDevice, c.CityTier, c.PreferredPaymentMode, c.Gender, c.PreferredOrderCat, c.SatisfactionScore, c.MaritalStatus, c.OrderCount, c.CashbackAmount, c.ChurnStatus, c.ComplaintReceived
FROM customer_returns AS r JOIN customer_churn AS c ON r.CustomerID=c.CustomerID
WHERE c.ChurnStatus='Churned' AND c.ComplaintReceived='Yes';
